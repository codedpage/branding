<?php
/**
 * All the widgets to be used as blocks
 */

class ContentBerg_Widgets_Blocks_Blog extends ContentBerg_Widgets_Base_Block {}

class ContentBerg_Widgets_Blocks_Highlights extends ContentBerg_Widgets_Base_Block {}

class ContentBerg_Widgets_Blocks_NewsGrid extends ContentBerg_Widgets_Base_Block {}

class ContentBerg_Widgets_Blocks_LoopGrid extends ContentBerg_Widgets_Base_Block {}

class ContentBerg_Widgets_Blocks_LoopGrid3 extends ContentBerg_Widgets_Base_Block {}

class ContentBerg_Widgets_Blocks_LoopList extends ContentBerg_Widgets_Base_Block {}